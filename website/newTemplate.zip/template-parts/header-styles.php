<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>

<style>.u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 90px;
}
.u-header .u-image-1 {
  margin: -18px auto 0 -38px;
}
.u-header .u-logo-image-1 {
  max-width: 235px;
  max-height: 235px;
}
.u-header .u-menu-1 {
  margin: -106px 0 22px auto;
}
.u-header .u-nav-1 {
  font-size: 1rem;
  letter-spacing: 0px;
}
.u-block-8737-19 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
.u-header .u-nav-2 {
  font-size: 1.25rem;
}
.u-block-8737-20 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
@media (max-width: 1199px) {
  .u-header .u-image-1 {
    margin-left: -38px;
    width: 64px;
    height: 32px;
  }
  .u-header .u-menu-1 {
    width: auto;
    margin-top: -106px;
  }
}
@media (max-width: 767px) {
  .u-header .u-image-1 {
    width: auto;
  }
}</style>
