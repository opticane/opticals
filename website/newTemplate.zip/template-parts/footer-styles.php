<!-- footer styles -->

<style>.u-footer {
  background-image: none;
}
.u-footer .u-sheet-1 {
  min-height: 185px;
}
.u-footer .u-image-1 {
  width: 119px;
  height: 119px;
  box-shadow: 0 2px 8px 0 rgba(128,128,128,1);
  background-image: ;
  background-position: 50% 50%;
  margin: 33px auto;
}
@media (max-width: 1199px) {
  .u-footer .u-image-1 {
    width: 119px;
    height: 119px;
  }
}</style>
